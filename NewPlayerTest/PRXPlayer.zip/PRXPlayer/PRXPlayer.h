//
//  PRXPlayer.h
//  NewPlayerTest
//
//  Created by Christopher Kalafarski on 9/17/13.
//  Copyright (c) 2013 Bitnock. All rights reserved.
//

@import UIKit;
@import AVFoundation;

#import "Reachability.h"

@protocol PRXPlayerItem, PRXPlayerDelegate;

extern NSString * const PRXPlayerChangeNotification;
extern NSString * const PRXPlayerTimeIntervalNotification;
extern NSString * const PRXPlayerLongTimeIntervalNotification;

extern NSString * const PRXPlayerReachabilityPolicyPreventedPlayback;

typedef NS_ENUM(NSUInteger, PRXPlayerState) {
  PRXPlayerStateUnknown,
  PRXPlayerStateEmpty,
  PRXPlayerStateLoading,
  PRXPlayerStateBuffering,
  PRXPlayerStateWaiting,
  PRXPlayerStateReady
};

@interface PRXPlayer : UIResponder {
  BOOL holdPlayback;
  
  NSUInteger retryCount;
  
  id playerPeriodicTimeObserver;
  
  NSUInteger backgroundKeepAliveTaskID;
  NSDate *dateAtAudioPlaybackInterruption;
  
  NetworkStatus previousReachabilityStatus;
  NSString *previousReachabilityString;
}

+ (instancetype)sharedPlayer;

@property (nonatomic, strong, readonly) AVPlayer *player;

@property (nonatomic, readonly) PRXPlayerState state;
@property (nonatomic, readonly) NSTimeInterval buffer;

@property (nonatomic, strong) id<PRXPlayerItem> playerItem;

@property (nonatomic, weak) id<PRXPlayerDelegate> delegate;

- (void)loadPlayerItem:(id<PRXPlayerItem>)playerItem;
- (void)playPlayerItem:(id<PRXPlayerItem>)playerItem;
- (void)togglePlayerItem:(id<PRXPlayerItem>)playerItem;

- (void)play;
- (void)pause;
- (void)toggle;
- (void)stop;

// this will go away
- (NSDate *)dateAtAudioPlaybackInterruption;

@end

@protocol PRXPlayerItem <NSObject>

@property (nonatomic, strong, readonly) AVAsset *playerAsset;

- (BOOL)isEqualToPlayerItem:(id<PRXPlayerItem>)aPlayerItem;

@optional

@property (nonatomic, strong, readonly) NSDictionary *mediaItemProperties;

// TODO better name
@property (nonatomic, readonly) CMTime playerTime;

- (void)setPlayerTime:(CMTime)playerTime;

@end

@protocol PRXPlayerDelegate <NSObject>

//- (void)player:(AVPlayer *)player changedToTime:(CMTime);
//- (void)playerDidTraverseSoftEndBoundaryTime:(PRXPlayer *)player;

@optional

- (float)filePlaybackRateForPlayer:(PRXPlayer *)player;
- (BOOL)playerAllowsPlaybackViaWWAN:(PRXPlayer *)player;
- (NSUInteger)retryLimitForPlayer:(PRXPlayer *)player;

@end
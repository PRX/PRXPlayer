//
//  PRXPlayer_private.h
//  NewPlayerTest
//
//  Created by Christopher Kalafarski on 9/24/13.
//  Copyright (c) 2013 Bitnock. All rights reserved.
//

@import MediaPlayer;

#import "PRXPlayer.h"


@interface PRXPlayer ()

@property (nonatomic, strong, readonly) Reachability *reach;
@property (nonatomic, strong) AVPlayer *player;

@property (nonatomic, readonly) float rateForFilePlayback;
@property (nonatomic, readonly) float rateForPlayback;

@property (nonatomic, readonly) BOOL allowsPlaybackViaWWAN;

@property (nonatomic, strong, readonly) NSDictionary *MPNowPlayingInfoCenterNowPlayingInfo;

- (void)postGeneralChangeNotification;

- (void)mediaPlayerCurrentItemStatusDidChange:(NSDictionary *)change;
- (void)mediaPlayerCurrentItemDidPlayToEndTime:(NSNotification *)notification;

@end